# SelectStar — Setup Guide

A clean, agentic database-analysis platform. Ask questions in plain English,
get tables, charts, EDA, models, and full narrative reports.

## Quick start

```bash
# 1. Install deps
bun install

# 2. Generate the Prisma client + push the schema to the local SQLite DB
bun run db:generate
bun run db:push

# 3. Seed the demo e-commerce database (optional but recommended)
node scripts/seed-demo.js

# 4. Start the dev server
bun run dev
```

Open http://localhost:3000 and click **Connect** (the demo connection string
is pre-filled — `demo`).

## What's new in this build

- **Light theme is the default** (was dark). Use the theme toggle in the
  top-right corner to switch back to dark.
- **No auto data-quality scan**. The canvas starts empty — the user drives
  the analysis via chat. (The data-quality agent code is still in
  `src/lib/agents/data-quality.ts` and the route still exists at
  `/api/data-quality/scan`, but nothing triggers it automatically.)
- **"What should I know?" and "What changed?" buttons are removed** from the
  chat header. The chat header now has just two actions:
  - **SQL** — toggle to show/hide generated SQL blocks on the canvas
    (default OFF; the canvas stays focused on results).
  - **New** — reset the session and go back to the connection screen.
- **"Include technical terms" toggle in the report plan** (default OFF).
  - **OFF (default)**: the report is written in plain English. No
    statistical jargon — "correlation" becomes "move together", "outlier"
    becomes "unusual value", "cluster" becomes "natural group", "skew"
    becomes "lopsided", "R²" is suppressed, "Pearson r" is hidden.
  - **ON**: the report uses the proper statistical terms with brief
    explanations.
- **Prisma query logs are silenced.** The dev console now only shows HTTP
  request summaries and warnings/errors. (Was flooding with `prisma:query`
  lines before.)
- **Human-in-the-loop UIs render inline in the chat**, not on the canvas:
  - Pending writes (Zen-mode confirmation: Confirm / Dry-run / Cancel)
  - Report plans (focus / depth / sections / Include-technicals / Generate)
  The canvas is now read-only analytical artifacts only (tables, charts,
  EDA, models, reports, data-quality scans).

## Connecting your own database

Replace `demo` with:
- `sqlite:./path/to/your.db` for a SQLite file
- `postgresql://user:pass@host:5432/db` for a Postgres database

For PostgreSQL, write privileges are detected automatically — Zen mode
becomes available if the role has `CREATE` privilege on the database.

## LLM configuration (optional)

The app falls back to a built-in LLM SDK when no `LLM_API_KEY` is set. To use
a real LLM (Groq, OpenAI, etc.), set these in `.env`:

```
LLM_BASE_URL=https://api.groq.com/openai/v1
LLM_API_KEY=your-key-here
LLM_MODEL=openai/gpt-oss-120b
```

## Project structure

```
src/
├─ app/
│  ├─ api/
│  │  ├─ chat/route.ts        (SSE stream, persists inlineArtifacts)
│  │  ├─ connect/route.ts     (test the DB connection)
│  │  ├─ confirm-write/route.ts
│  │  ├─ sessions/[id]/route.ts
│  │  ├─ data-quality/scan/route.ts  (still present, no longer auto-called)
│  │  └─ ...
│  ├─ layout.tsx
│  └─ page.tsx
├─ components/
│  ├─ canvas-pane.tsx        (filters HITL + SQL when off)
│  ├─ chat-pane.tsx          (Show SQL toggle, HITL inline renderer)
│  ├─ app-shell.tsx          (no auto DQ scan)
│  ├─ theme-provider.tsx     (defaultTheme="light", enableSystem=false)
│  ├─ canvas/canvas-report-plan.tsx  (Include-technicals toggle)
│  ├─ canvas/canvas-report.tsx       (technical/plain-English badge)
│  └─ ...
├─ lib/
│  ├─ store.ts               (showSql, inlineArtifacts)
│  ├─ session.ts             (restores inlineArtifacts on reload)
│  ├─ types.ts               (includeTechnicals on ReportCanvasObject,
│  │                          defaultIncludeTechnicals on ReportPlan)
│  ├─ db.ts                  (log: ['warn', 'error'] only)
│  ├─ agents/report.ts       (plain-English narrator + pattern mining)
│  └─ ...
└─ ...
prisma/schema.prisma
scripts/seed-demo.js
```

## Verifying it works

1. `bun run dev`
2. Open http://localhost:3000
3. Click **Connect** (demo string pre-filled).
4. Canvas should be **empty** (no auto data-quality scan).
5. Chat header should show only **SQL** (default OFF) and **New** — no
   "What should I know?" or "What changed?".
6. Click any starter question — you'll see the result table on the canvas
   with NO SQL block. Click **SQL** in the chat header → the SQL block
   appears.
7. Click **"Generate a full report with hidden-pattern analysis"** → the
   report plan appears inline in the chat with an **"Include technical
   terms"** toggle (default OFF). Click **Generate Report**.
8. The report renders on the canvas with a `plain English` badge in the
   header. Toggle **Include technical terms** ON, regenerate → the badge
   switches to `technical`.

Enjoy!
