"use client";

import { useRef, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LayoutDashboard, Sparkles, Trash2, ArrowDown, Table2 } from "lucide-react";
import { useSession } from "@/lib/store";
import { CanvasObjectView } from "@/components/canvas/canvas-object";
import { SpreadsheetGrid } from "@/components/classic/spreadsheet-grid";
import { toast } from "sonner";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function CanvasPane() {
  const canvas = useSession((s) => s.canvas);
  const mode = useSession((s) => s.mode);
  const sessionId = useSession((s) => s.sessionId);
  const showSql = useSession((s) => s.showSql);
  const clearCanvas = () => {
    useSession.setState({ canvas: [] });
    toast.success("Canvas cleared");
  };

  // Visible canvas items.
  // - HITL artifacts (pending_write, report_plan) render inline in chat, not here.
  // - SQL blocks render only when the user has "Show SQL" turned on in the chat header.
  //   When off (default), the canvas stays focused on results — tables, charts, EDA,
  //   model results, reports, and data-quality scans.
  const visibleCanvas = canvas.filter(
    (o) =>
      o.type !== "pending_write" &&
      o.type !== "report_plan" &&
      (showSql || o.type !== "sql")
  );

  const scrollRef = useRef<HTMLDivElement>(null);
  const [showScrollDown, setShowScrollDown] = useState(false);
  const [tab, setTab] = useState<"spreadsheet" | "canvas">(
    mode === "classic" ? "spreadsheet" : "canvas"
  );
  // Sync `tab` with `mode` — use the "adjust state during render" pattern
  // (https://react.dev/reference/react/useState#storing-information-from-previous-renders)
  // instead of calling setState inside an effect, which would trigger
  // cascading renders.
  const [prevMode, setPrevMode] = useState(mode);
  if (mode !== prevMode) {
    setPrevMode(mode);
    setTab(mode === "classic" ? "spreadsheet" : "canvas");
  }

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
      setShowScrollDown(distFromBottom > 120);
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="flex flex-col h-full bg-muted/20">
      <div className="flex items-center gap-2 px-4 h-12 border-b border-border bg-background shrink-0">
        <LayoutDashboard className="h-4 w-4 text-primary" />
        <span className="font-medium text-sm">{mode === "classic" ? "Workbook" : "Canvas"}</span>
        <span className="text-xs text-muted-foreground">·</span>
        {mode === "classic" ? (
          <Tabs value={tab} onValueChange={(v) => setTab(v as "spreadsheet" | "canvas")}>
            <TabsList className="h-7">
              <TabsTrigger value="spreadsheet" className="text-xs gap-1 px-2 h-5">
                <Table2 className="h-3 w-3" /> Spreadsheet
              </TabsTrigger>
              <TabsTrigger value="canvas" className="text-xs gap-1 px-2 h-5 relative">
                <LayoutDashboard className="h-3 w-3" /> Canvas
                {visibleCanvas.length > 0 && (
                  <span className="ml-0.5 inline-flex items-center justify-center min-w-4 h-4 px-1 rounded-full bg-primary text-primary-foreground text-[9px] font-medium tabular-nums">
                    {visibleCanvas.length}
                  </span>
                )}
              </TabsTrigger>
            </TabsList>
          </Tabs>
        ) : (
          <span className="text-xs text-muted-foreground">
            {visibleCanvas.length} {visibleCanvas.length === 1 ? "artifact" : "artifacts"}
          </span>
        )}
        {visibleCanvas.length > 0 && (mode !== "classic" || tab === "canvas") && (
          <button
            onClick={clearCanvas}
            className="ml-auto inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted-foreground hover:text-destructive hover:bg-destructive/5 transition-colors"
            title="Clear canvas"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        )}
      </div>

      {mode === "classic" && tab === "spreadsheet" && sessionId ? (
        <SpreadsheetGrid sessionId={sessionId} />
      ) : (
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0 relative">
          <AnimatePresence initial={false}>
            {/* HITL artifacts (pending_write, report_plan) are rendered inline
                in the chat pane, not here — keeps the canvas focused on
                read-only analytical artifacts (tables, charts, EDA, models,
                reports, data-quality scans). */}
            {visibleCanvas.length === 0 ? (
              <EmptyCanvas key="empty" mode={mode} />
            ) : (
              visibleCanvas.map((obj, i) => (
                <motion.div
                  key={i}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                  className="animate-canvas-in group/canvas relative"
                >
                  <CanvasObjectView obj={obj} />
                </motion.div>
              ))
            )}
          </AnimatePresence>
          {showScrollDown && (
            <button
              onClick={() => {
                const el = scrollRef.current;
                if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
              }}
              className="sticky bottom-2 left-full ml-auto flex h-8 w-8 items-center justify-center rounded-full bg-background border border-border shadow-md hover:bg-accent transition-colors"
              title="Scroll to bottom"
            >
              <ArrowDown className="h-4 w-4 text-muted-foreground" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function EmptyCanvas({ mode }: { mode?: "sql" | "classic" }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center py-16">
      <div className="h-12 w-12 rounded-2xl bg-muted border border-border flex items-center justify-center mb-3">
        <Sparkles className="h-6 w-6 text-muted-foreground" />
      </div>
      <h3 className="font-medium text-sm text-muted-foreground">Your canvas is empty</h3>
      <p className="text-xs text-muted-foreground/70 mt-1 max-w-xs">
        {mode === "classic"
          ? "Tables, charts, and EDA summaries from your conversation will appear here. Switch to the Spreadsheet tab to edit the data directly."
          : "Tables, charts, statistical summaries and model results from your conversation will appear here — like a living notebook. SQL blocks are hidden by default; flip the SQL toggle in the chat header to see them."}
      </p>
    </div>
  );
}
