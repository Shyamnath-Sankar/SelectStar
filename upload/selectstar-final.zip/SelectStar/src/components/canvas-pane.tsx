"use client";

import { useRef, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LayoutDashboard, Sparkles, Trash2, ArrowDown, Table2, HelpCircle } from "lucide-react";
import { useSession } from "@/lib/store";
import { CanvasObjectView } from "@/components/canvas/canvas-object";
import { SpreadsheetGrid } from "@/components/classic/spreadsheet-grid";
import { toast } from "sonner";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { streamChat } from "@/lib/chat-client";
import type { CanvasObject } from "@/lib/types";

export function CanvasPane() {
  const canvas = useSession((s) => s.canvas);
  const mode = useSession((s) => s.mode);
  const sessionId = useSession((s) => s.sessionId);
  const clearCanvas = () => {
    useSession.setState({ canvas: [] });
    toast.success("Canvas cleared");
  };

  const scrollRef = useRef<HTMLDivElement>(null);
  const [showScrollDown, setShowScrollDown] = useState(false);
  const [tab, setTab] = useState<"spreadsheet" | "canvas">(
    mode === "classic" ? "spreadsheet" : "canvas"
  );

  useEffect(() => {
    setTab(mode === "classic" ? "spreadsheet" : "canvas");
  }, [mode]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
      setShowScrollDown(distFromBottom > 120);
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="flex flex-col h-full bg-muted/20">
      <div className="flex items-center gap-2 px-4 h-12 border-b border-border bg-background shrink-0">
        <LayoutDashboard className="h-4 w-4 text-primary" />
        <span className="font-medium text-sm">{mode === "classic" ? "Workbook" : "Canvas"}</span>
        <span className="text-xs text-muted-foreground">·</span>
        {mode === "classic" ? (
          <Tabs value={tab} onValueChange={(v) => setTab(v as "spreadsheet" | "canvas")}>
            <TabsList className="h-7">
              <TabsTrigger value="spreadsheet" className="text-xs gap-1 px-2 h-5">
                <Table2 className="h-3 w-3" /> Spreadsheet
              </TabsTrigger>
              <TabsTrigger value="canvas" className="text-xs gap-1 px-2 h-5 relative">
                <LayoutDashboard className="h-3 w-3" /> Canvas
                {canvas.length > 0 && (
                  <span className="ml-0.5 inline-flex items-center justify-center min-w-4 h-4 px-1 rounded-full bg-primary text-primary-foreground text-[9px] font-medium tabular-nums">
                    {canvas.length}
                  </span>
                )}
              </TabsTrigger>
            </TabsList>
          </Tabs>
        ) : (
          <span className="text-xs text-muted-foreground">
            {canvas.length} {canvas.length === 1 ? "artifact" : "artifacts"}
          </span>
        )}
        {canvas.length > 0 && (mode !== "classic" || tab === "canvas") && (
          <button
            onClick={clearCanvas}
            className="ml-auto inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted-foreground hover:text-destructive hover:bg-destructive/5 transition-colors"
            title="Clear canvas"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        )}
      </div>

      {mode === "classic" && tab === "spreadsheet" && sessionId ? (
        <SpreadsheetGrid sessionId={sessionId} />
      ) : (
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0 relative">
          <AnimatePresence initial={false}>
            {canvas.length === 0 ? (
              <EmptyCanvas key="empty" mode={mode} />
            ) : (
              canvas.map((obj, i) => (
                <motion.div
                  key={i}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                  className="animate-canvas-in group/canvas relative"
                >
                  <CanvasObjectView obj={obj} />
                  <CanvasExplainButton obj={obj} index={i} />
                </motion.div>
              ))
            )}
          </AnimatePresence>
          {showScrollDown && (
            <button
              onClick={() => {
                const el = scrollRef.current;
                if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
              }}
              className="sticky bottom-2 left-full ml-auto flex h-8 w-8 items-center justify-center rounded-full bg-background border border-border shadow-md hover:bg-accent transition-colors"
              title="Scroll to bottom"
            >
              <ArrowDown className="h-4 w-4 text-muted-foreground" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}

/**
 * A small "Explain this simply" button overlay shown at the top-right of each
 * canvas card on hover. Clicking sends a chat message asking the synthesis
 * agent to re-explain the artifact in plain English.
 *
 * Hidden on pending_write cards (where confirmation UI is the priority) and
 * on report_plan cards (where the action is "Generate Report" instead).
 */
function CanvasExplainButton({ obj, index }: { obj: CanvasObject; index: number }) {
  const sessionId = useSession((s) => s.sessionId);
  const sending = useSession((s) => s.sending);
  const addMessage = useSession((s) => s.addMessage);
  const appendToMessage = useSession((s) => s.appendToMessage);
  const addStepToMessage = useSession((s) => s.addStepToMessage);
  const addCanvasObject = useSession((s) => s.addCanvasObject);
  const setFollowUps = useSession((s) => s.setFollowUps);
  const finalizeMessage = useSession((s) => s.finalizeMessage);
  const setSending = useSession((s) => s.setSending);

  // Skip the button for cards where the user's primary action is something else.
  if (obj.type === "pending_write" || obj.type === "report_plan") return null;

  async function explain() {
    if (!sessionId || sending) return;
    // Build a context-rich prompt so the synthesis agent knows which artifact
    // we're asking about, without burying the original question text.
    const artifactDesc = describeForPrompt(obj);
    const prompt = `Explain the ${obj.type.replace(/_/g, " ")} I'm looking at right now (canvas card #${index + 1}) in plain English — assume I have no data background. ${artifactDesc}`;
    addMessage({ id: crypto.randomUUID(), role: "user", content: `Explain canvas card #${index + 1} simply` });
    const assistantId = crypto.randomUUID();
    addMessage({ id: assistantId, role: "assistant", content: "", streaming: true, steps: [] });
    setSending(true);
    await streamChat(sessionId, prompt, {
      onStep: (agent, label) => addStepToMessage(assistantId, { agent, label }),
      onSql: () => {},
      onCanvas: (o) => addCanvasObject(o),
      onToken: (delta) => appendToMessage(assistantId, delta),
      onFollowUps: (qs) => setFollowUps(assistantId, qs),
      onReplyDone: () => finalizeMessage(assistantId),
      onError: (msg) => {
        appendToMessage(assistantId, `⚠️ ${msg}`);
        finalizeMessage(assistantId, { isError: true });
      },
      onDone: () => {
        finalizeMessage(assistantId);
        setSending(false);
      },
    });
  }

  return (
    <button
      onClick={() => void explain()}
      disabled={sending}
      className="absolute top-2 right-2 z-10 inline-flex items-center gap-1 rounded-md border border-border bg-background/95 backdrop-blur-sm px-1.5 py-0.5 text-[10px] text-muted-foreground hover:text-primary hover:border-primary/40 hover:bg-background shadow-sm opacity-0 group-hover/canvas:opacity-100 transition-all disabled:opacity-50"
      title="Explain this in plain English"
    >
      <HelpCircle className="h-3 w-3" />
      <span className="hidden sm:inline">Explain</span>
    </button>
  );
}

/** Build a short, context-rich prompt fragment describing the artifact. */
function describeForPrompt(obj: CanvasObject): string {
  switch (obj.type) {
    case "table":
      return `It's a table${obj.title ? ` titled "${obj.title}"` : ""} with ${(obj.totalRows ?? obj.rows.length).toLocaleString()} rows and columns: ${obj.columns.map((c) => c.name).join(", ")}.`;
    case "chart":
      return `It's a chart${obj.title ? ` titled "${obj.title}"` : ""}. Caption: ${obj.caption || "(none)"}.`;
    case "sql":
      return `It's a SQL query that ${obj.executed ? `returned ${obj.rowCount ?? 0} rows` : "failed to execute"}.${obj.error ? ` Error: ${obj.error}` : ""}`;
    case "eda_summary":
      return `It's a statistical summary of ${obj.columns.length} columns. ${obj.insights?.length ? `${obj.insights.length} notable correlations.` : "No strong correlations."}`;
    case "model_result":
      return `It's a ${obj.modelType} model result. Explanation: ${obj.explanation || "(none)"}`;
    case "report":
      return `It's a full report titled "${obj.title}" with ${obj.sections.length} sections and ${obj.hiddenPatterns.length} hidden patterns.`;
    case "data_quality":
      return `It's a data quality scan with ${obj.issues.length} issues found (health score ${obj.healthScore}/100).`;
    case "error":
      return `It's an error message: ${obj.message}`;
    default:
      return "";
  }
}

function EmptyCanvas({ mode }: { mode?: "sql" | "classic" }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center py-16">
      <div className="h-12 w-12 rounded-2xl bg-muted border border-border flex items-center justify-center mb-3">
        <Sparkles className="h-6 w-6 text-muted-foreground" />
      </div>
      <h3 className="font-medium text-sm text-muted-foreground">Your canvas is empty</h3>
      <p className="text-xs text-muted-foreground/70 mt-1 max-w-xs">
        {mode === "classic"
          ? "Tables, charts, and EDA summaries from your conversation will appear here. Switch to the Spreadsheet tab to edit the data directly."
          : "Tables, charts, SQL, statistical summaries and model results from your conversation will appear here — like a living notebook."}
      </p>
    </div>
  );
}
