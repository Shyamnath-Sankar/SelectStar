# SelectStar — Feature Suggestions for the "Zero-Experience Data Analysis" Vision

> Companion document to the **Report Agent** implementation. Built on top of
> the [SelectStar](https://github.com/Shyamnath-Sankar/SelectStar) codebase.
> All suggestions here are scoped to the existing TypeScript / Next.js /
> Vega-Lite / OpenAI-compatible-LLM stack — no Python rewrite required.

---

## 1. What was built (summary)

A new **Report Agent** was added to the SelectStar orchestrator graph. It
sits alongside the existing six agents (router, schema, sql, eda, viz, ml)
and produces a *narrative, end-to-end deliverable* — not just a single
chart or a single stat.

**Two-phase, human-in-the-loop flow:**

1. **Planner phase** — When the user says "give me a report", "what does this
   data tell me", "find hidden patterns", etc., the router routes to the
   `report` agent. The planner emits an interactive `report_plan` canvas
   card with focus-area options, depth options (quick / standard / deep),
   and section checkboxes. **No analysis happens until the user picks
   options.** This is the human-in-the-loop gate.

2. **Generator phase** — When the user clicks "Generate Report", the chat
   client sends a structured `__GENERATE_REPORT__ {...}` message back to
   the orchestrator. The router detects this prefix and routes back into
   the report agent's generator. The generator:
   - Acquires a dataframe (reuses the last SQL result, or runs a sample
     SELECT against the most relevant table).
   - Runs pure-TypeScript hidden-pattern mining: outliers via IQR,
     Pareto concentration, top Pearson correlations, linear-trend slopes
     with R², distribution skewness, null-rate patterns, range anomalies,
     and mini k-means clustering.
   - Asks the LLM to narrate the findings in plain English (no jargon).
   - Returns a structured `report` canvas object with: executive summary,
     key metrics row, hidden-pattern callouts (severity-coloured,
     expandable), per-section Markdown body, recommended next questions,
     and a downloadable Markdown export.

**Files added/changed:**

| File | Change |
| --- | --- |
| `src/lib/types.ts` | Added `report` to `AgentName`; added `HiddenPattern`, `ReportSection`, `ReportKeyMetric`, `ReportCanvasObject`, `ReportPlanOption`, `ReportPlanCanvasObject`; extended the `CanvasObject` union. |
| `src/lib/agents/report-constants.ts` | New — client-safe `GENERATE_REPORT_PREFIX` + `isGenerateReportMessage`. |
| `src/lib/agents/report.ts` | New (~700 lines) — planner + generator + hidden-pattern mining. |
| `src/lib/agents/router.ts` | Added `report` to system prompt + `allowed` list; added 3 fast-path branches. |
| `src/lib/agents/orchestrator.ts` | Wired a `report` node that branches on planner vs. generator phase. |
| `src/lib/agents/synthesis.ts` | Extended `describeCanvas` + system prompt for new canvas types. |
| `src/components/canvas/canvas-report-plan.tsx` | New — interactive options card. |
| `src/components/canvas/canvas-report.tsx` | New — final report renderer + Markdown export. |
| `src/components/canvas/canvas-object.tsx` | Added dispatcher cases. |
| `src/components/chat-pane.tsx` | Added `report` agent icon + a one-tap "Generate a full report" empty-state button. |

**TypeScript:** zero new errors introduced (verified against the unmodified
`main` branch — both versions have the same 29 pre-existing errors).

---

## 2. The core problem we're solving

The user's stated mission is:

> *normal people analyse data such that data analysis courses like PowerBI
> and Tableau used by experts but these tool makes people to analyse data
> with 0 experience.*

Translating that into concrete design constraints:

1. **The user does not know what questions exist to ask.** Power BI gives
   you a blank canvas and says "build a dashboard" — that's a non-starter
   for someone who has never built one. The tool has to *suggest* the
   questions.
2. **The user does not know what a "good" answer looks like.** A pivot
   table is not enough — they need an explanation in plain English of
   what the numbers mean.
3. **The user does not know what they don't know.** The tool has to
   surface *hidden patterns* proactively — things the user would never
   have thought to ask about.
4. **The user is afraid of breaking things.** Every destructive action
   needs an explicit confirmation, an undo, and a sandbox.
5. **The user does not have time.** Each round-trip should be measured in
   seconds, not minutes. Pre-emptive caching, parallel agents, and
   streaming replies are non-negotiable.

The Report Agent addresses #1, #2, and #3 directly. The suggestions below
build on that foundation.

---

## 3. Suggested features, prioritised by impact-to-effort ratio

### Tier 1 — high impact, low effort (do these next)

#### 3.1 "What should I know?" one-click shortcut

The Report Agent already supports a focus option called `anomalies` /
`hidden_patterns`. Add a prominent button at the top of the chat pane:

> *"What should I know?"* — one click runs the report agent with
> `focus=anomalies`, `depth=quick`, `sections=[hidden_patterns,
> recommendations]`.

**Why it matters:** Non-experts don't know how to phrase a question. A
single button labelled with the *outcome* they want ("tell me what
matters") removes the cold-start problem entirely.

**Implementation:** A button in the chat header that calls `send()` with
a pre-baked prompt. Reuses the existing pipeline.

---

#### 3.2 Glossary tooltips on every statistical term

When the report mentions "outlier", "correlation", "median", "skew",
"Pareto", "R²" — these should be hoverable. A tooltip explains the term
in one sentence.

**Why it matters:** A non-expert sees "r = 0.82" and has no idea what
that means. A 2-second hover explaining *"strong positive relationship —
when one goes up, the other tends to go up too"* is the difference
between a useful report and an intimidating one.

**Implementation:** Build a small dictionary `Record<string, string>` of
~30 terms. In `canvas-report.tsx`, render the markdown body through a
custom `ReactMarkdown` component that wraps known terms in a Radix
`<Tooltip>`.

---

#### 3.3 Plain-English chart titles + auto-annotations

The viz agent currently produces titles like *"Top products by revenue"*
— fine, but not great. Improve the system prompt to emit *annotated*
titles:

> *"Revenue by Month — **+34% growth** from Jan to Dec 2024"*

Plus add automatic annotations to the Vega-Lite spec for outliers
(arrows pointing at the spike).

**Why it matters:** A chart with a narrative title answers "so what?"
before the user has to ask.

**Implementation:** Add a post-processing step in `viz.ts` that
inspects the produced spec and injects `mark: { type: "...", tooltip:
true }` plus an `annotations` array.

---

#### 3.4 Suggested follow-up questions after every assistant reply

The Report Agent already produces `recommendedQuestions`. Extend this
pattern to *every* synthesis reply — when the user asks "what's the
total revenue?", the synthesis agent should also emit 2-3 clickable
suggestions: *"Who are the top customers?"*, *"How has revenue changed
over time?"*, *"Which products drive most revenue?"*.

**Why it matters:** Solves the cold-start problem after the first
question. The user is never stuck wondering what to ask next.

**Implementation:** Update `synthesis.ts` to output a JSON shape that
includes `followUps: string[]`. Render them as chips below the
assistant reply in `chat-pane.tsx`.

---

#### 3.5 "Explain this simply" button on every canvas artifact

Add a small `?` icon in the corner of every canvas card (table, chart,
EDA summary, model result, report). Clicking it sends a chat message:
*"Explain [artifact] like I'm 5"* — the synthesis agent re-narrates the
artifact in even simpler language.

**Why it matters:** Some users will find even the report's plain English
too technical. A one-click "simpler please" escape hatch respects
different literacy levels.

**Implementation:** Pass an artifact id through the chat message. The
synthesis agent already receives the canvas list — just needs a system
prompt branch.

---

#### 3.6 Auto data-quality scan on connect

When a database connects, run a quick quality scan in the background:

- % of nulls per column (already in EDA agent)
- Duplicate primary keys (count rows where PK appears > 1)
- Out-of-range values (negative prices, future dates, etc.)
- Email/phone format validation (regex)

Surface a non-blocking banner: *"I found 4 data quality issues — review
them"* with a link to a `data_quality` canvas card listing each issue
in plain English.

**Why it matters:** Bad data = bad analysis. Non-experts won't think
to check this themselves. Doing it automatically is a 10× trust boost.

**Implementation:** New `data_quality` agent or extend the schema agent.
Reuse the EDA agent's null-detection code.

---

### Tier 2 — high impact, medium effort

#### 3.7 Domain templates ("Sales", "Marketing", "HR", "Operations", "Finance")

When a user connects to a database, auto-detect the domain by table
names (`orders`/`customers`/`products` → Sales; `employees`/`salaries`
→ HR). Show a banner: *"Looks like a Sales database — want me to use
the Sales template?"*

Each template ships:

- 10 curated starter questions (instead of the generic 4 today)
- A pre-filled "first report" with sensible defaults
- Domain-specific hidden-pattern detectors (e.g. for Sales: customer
  churn, basket size, repeat purchase rate)

**Why it matters:** Generic starters are good; domain-specific starters
are *magical*. A Sales manager sees "Who are my top 10 customers by
repeat purchase rate?" and immediately knows the tool understands their
world.

**Implementation:** `src/lib/templates/sales.ts`, `marketing.ts`, etc.
Each exports `detect(schema)`, `starterQuestions(schema)`, and
`hiddenPatternDetectors()`.

---

#### 3.8 Side-by-side comparison mode

When the user asks *"Compare X vs Y"* (e.g. "compare Q1 vs Q2", "compare
US vs EU", "compare 2023 vs 2024"), the SQL agent should automatically
produce two result sets, and the canvas should render them side-by-side
with a delta column showing the % change.

**Why it matters:** Comparison is the single most common analytical
question. Power BI users build whole dashboards for this; SelectStar
can do it from one sentence.

**Implementation:** Add a `compare` canvas object type. Update the SQL
agent to detect comparison intent and produce two queries. New
`canvas-compare.tsx` component with a two-column layout + delta column.

---

#### 3.9 "What changed?" — auto-diff against last period

Add a one-click action: *"What changed since last month?"* The agent:

1. Detects date columns
2. Identifies the most recent complete period (e.g. last month)
3. Compares to the prior period across every key metric
4. Surfaces a sorted list of biggest movers (+ and -)
5. Generates a 1-paragraph summary

**Why it matters:** This is the #1 question every business user asks
every Monday morning. Doing it in one click is the killer feature.

**Implementation:** A new `diff` agent, or extend the report agent with
a `what_changed` focus option.

---

#### 3.10 Story mode (PowerPoint-style walkthrough)

When a report is generated, add a "Walk me through it" button that:

1. Maximises the canvas
2. Highlights the executive summary
3. Auto-scrolls to each hidden pattern, one at a time, with a 5-second
   pause
4. Ends on the recommendations

A "Next" button lets the user advance manually; an "Auto-play" button
runs the whole thing.

**Why it matters:** A 5-section report is intimidating. A
slide-by-slide walkthrough feels like a colleague explaining the data
over your shoulder.

**Implementation:** Framer Motion already in the project. Use scroll
into view + a small state machine.

---

#### 3.11 PDF and PowerPoint export of reports

Currently the report exports to Markdown (great for engineers, useless
for non-technical stakeholders). Add:

- "Export as PDF" — uses the existing Vega-Lite SVG charts + the
  Markdown body, renders via a headless Chromium step (or a server-side
  `puppeteer` route). Already available in the project's Dockerfile.
- "Export as PPTX" — one slide per section, chart as image, bullets as
  speaker notes. Use the `pptxgenjs` library (already a common pattern).

**Why it matters:** The most common use case for a report is to share
it with someone who wasn't in the room. A PDF/PPTX makes the report
*portable*.

**Implementation:** Add `/api/report/export?format=pdf` and
`/api/report/export?format=pptx` endpoints. Pass the report JSON, render
server-side.

---

#### 3.12 "Explain like I'm 5" toggle in settings

Add a global "Simplicity" slider in the header: Levels 1-5. Level 5
rewrites every synthesis reply at a 5th-grade reading level. Level 1
keeps the technical tone.

**Why it matters:** Different audiences need different registers. A
CEO wants "revenue grew 34%"; an analyst wants "y = 0.34x + 1.2, R² =
0.87". One slider handles both.

**Implementation:** Add `simplicityLevel` to the session state. Update
the synthesis system prompt to branch on it.

---

### Tier 3 — strategic, higher effort

#### 3.13 Voice input + voice output

- **Voice input:** Use the browser's `webkitSpeechRecognition` API.
  A microphone icon next to the chat input. Great for users on mobile
  or who are uncomfortable typing.
- **Voice output:** Use the `z-ai-web-dev-sdk` TTS skill to read the
  synthesis reply aloud. A "Read aloud" button below every assistant
  message.

**Why it matters:** Voice is the most natural interface for
non-experts. A user who can speak a question and hear the answer
doesn't need to know *any* technical vocabulary.

**Implementation:** The project already has the TTS skill available;
just wire it into the chat pane.

---

#### 3.14 Public shareable links for reports

When a report is generated, add a "Share" button that creates a public
URL: `selectstar.app/r/<id>`. Anyone with the link can view the report
(read-only) without connecting to a database.

**Why it matters:** The most common reason to generate a report is to
share it. Currently the report lives inside the session; a public link
makes it *portable*.

**Implementation:** New `Report` Prisma model. New `/r/[id]` route.
Add a "Public link" generation button.

---

#### 3.15 Proactive alerts ("while you were away")

When the user reconnects to a previously-used session, run a quick diff:

- Has the schema changed?
- Have new rows been added since last visit?
- Has any metric moved by > X%?

Surface a banner: *"3 things changed since you were last here — review"*

**Why it matters:** Turns SelectStar from a "tool you use when you
remember to" into a "tool that nudges you when something matters".

**Implementation:** Store a `lastVisitedAt` per session. On reconnect,
run a small diff agent. Compare to the cached schema snapshot.

---

#### 3.16 Multi-language support

Add i18n for the UI (Hindi, Spanish, Mandarin, etc.). For agent
replies, add a "Reply in [language]" selector that prompts the synthesis
agent to switch language.

**Why it matters:** The mission is to make data analysis accessible to
*normal people* — most of whom don't speak English as a first language.

**Implementation:** `next-intl` is already in `package.json`. Wire it
up. The synthesis agent just needs the target language injected into
the system prompt.

---

#### 3.17 "What if?" simulator

In Zen mode (writes allowed), add a *"What if?"* mode:

- *"What if I deleted all customers from region X?"* → runs a
  transaction, shows the effect, rolls back automatically. The user
  sees the impact without committing.
- *"What if I gave everyone a 10% discount?"* → computes the revenue
  impact on existing orders, surfaces a preview.

**Why it matters:** Non-experts are terrified of "breaking" the
database. A simulator lets them explore safely.

**Implementation:** Extend the existing dry-run/rollback Zen-mode
machinery. Add a `simulate` flag to the SQL agent.

---

#### 3.18 Concept map / schema visualiser

A graph view of the database: tables as nodes, foreign keys as edges.
Clicking a table shows its columns. Clicking a column shows its
distribution.

**Why it matters:** Non-experts have no mental model of how tables
relate. A visual graph is 10× more intuitive than `information_schema`
text.

**Implementation:** Use `react-flow` or `d3-force`. Add a new tab in
the canvas pane next to "Spreadsheet" / "Canvas".

---

#### 3.19 Collaborative comments on canvas artifacts

Let users add comments to any canvas card. Comments are persisted in
Prisma. A small comment count badge appears on each card.

**Why it matters:** Data analysis is rarely a solo activity. Comments
turn SelectStar from a tool into a workspace.

**Implementation:** New `Comment` Prisma model. New
`/api/comments/[canvasObjectId]` route. Small comment panel inside
each canvas card.

---

#### 3.20 Embedded "lessons" — micro-learning inline

When the Report Agent surfaces a Pareto pattern for the first time,
show a small collapsible card:

> **The 80/20 rule (Pareto Principle)**
> A common pattern in business data: a small number of items account
> for most of the value. ~20% of customers typically drive ~80% of
> revenue. Read more →

Clicking "Read more" opens a 2-paragraph primer with an example.

**Why it matters:** Educates the user in-context, where they care. They
just saw the pattern; now they understand it. No separate "data
analysis course" needed — SelectStar *is* the course.

**Implementation:** `src/lib/lessons/<topic>.md` files keyed by pattern
kind. Render conditionally based on whether the user has seen the
lesson before (track in localStorage).

---

## 4. Architectural principles to preserve as we add features

The codebase already follows six good principles (transparency,
read-only by default, narrow agents, canvas vs. chat separation,
dialect-agnostic, calm UI). Add these as we extend:

1. **The graph orchestrator stays the graph.** Don't fall back to a
   ReAct loop. Every new capability is a new node or a new option on
   an existing node — never a free-form LLM tool palette.

2. **Every destructive action stays gated.** Zen mode + confirmation
   is non-negotiable. The "What if?" simulator (3.17) reuses the
   dry-run/rollback machinery, never bypasses it.

3. **Every number has a provenance.** A user should always be able to
   click any number in a report and see: the SQL that produced it, the
   agent reasoning, the time it ran. No "trust me" numbers.

4. **Every reply has a next step.** No dead ends. If the agent can't
   answer, it must suggest what to ask instead. If it can, it must
   suggest what to ask next.

5. **Plain English is a feature, not a nicety.** Every metric, every
   pattern, every chart annotation must be rephrasable to a 5th-grade
   reading level on demand. Jargon is the enemy.

6. **The UI stays calm.** One accent colour. Whitespace. Subtle motion.
   Restraint reads as expensive. Adding features must not add visual
   clutter — each new feature earns its pixels.

---

## 5. Recommended next 4-week build order

| Week | Focus | Deliverables |
| --- | --- | --- |
| **Week 1** | Polish the Report Agent | Glossary tooltips (3.2), "What should I know?" button (3.1), suggested follow-ups after every reply (3.4), "Explain this simply" button (3.5). |
| **Week 2** | Trust & data quality | Auto data-quality scan on connect (3.6), provenance links on every number, PDF/PPTX export of reports (3.11). |
| **Week 3** | Domain templates | Sales + Marketing + HR templates (3.7), side-by-side comparison mode (3.8), "What changed?" diff agent (3.9). |
| **Week 4** | Voice + share + lessons | Voice input/output (3.13), public shareable links (3.14), inline micro-lessons (3.20), "Explain like I'm 5" toggle (3.12). |

By the end of week 4, SelectStar will have moved from "agentic
database-analysis platform" to "the data analyst for people who don't
have a data analyst" — which is the stated mission.

---

## 6. Quick wins that need no new code

These are configurations / prompt tweaks that improve the non-expert
experience immediately:

1. **Lower the synthesis temperature** from `0.4` to `0.3` for more
   predictable, less flowery prose.
2. **Add "show your work" to every reply** — append a small "How I got
   this" collapsible showing the SQL the agent ran.
3. **Default depth to "standard"** in the report planner — most users
   want the middle option.
4. **Cap hidden patterns at 5 for "quick" depth** — too many patterns
   overwhelm; 5 is the sweet spot.
5. **Make the "Generate Report" empty-state button pulse subtly** on
   first connect — non-experts need a visual nudge.
6. **Add a `cacheSchema` option to the schema agent** — when the same
   user re-opens a session, skip the introspection query.

---

## 7. Open research questions

These are areas where I don't yet have a strong opinion and would
benefit from user testing:

1. **Does the human-in-the-loop plan actually help, or does it feel like
   friction?** A/B test: half of users get the plan card, half get the
   report generated immediately with sensible defaults.

2. **How long should a "quick" report take?** Currently the planner
   phase is fast (~2s), but the generator phase runs SQL + LLM narration
   which can take 8-15s. Is that acceptable, or do we need a streaming
   "draft → refine" UX?

3. **Should the report be re-generatable?** Today each click of
   "Generate Report" produces a new report card. Should we replace the
   previous one, or stack them? My instinct is stack (so the user can
   compare reports over time), but that adds clutter.

4. **Should the report support free-text editing?** A non-expert might
   want to tweak the executive summary before sharing with their boss.
   An inline editable report body would be powerful but complex.

5. **Should the LLM call stream during report generation?** Currently
   the generator runs everything then emits the final report as one
   canvas object. Streaming the executive summary first, then each
   section, would feel faster — but it's a bigger refactor.

---

## 8. Summary

The Report Agent is the foundation for the "zero-experience data
analysis" vision. It already does the hard part: mines hidden patterns,
narrates them in plain English, and respects the user's time with a
human-in-the-loop planner.

The 20 suggestions above are the next layer — turning a *tool* into a
*colleague*. The guiding principle throughout is: **the tool's job is
not to do analysis for the user; it's to make the user an analyst**.
Every glossary tooltip, every "what should I know?" button, every inline
micro-lesson moves the user one step closer to being able to do this
themselves next time.

That's the real mission. Not "AI replaces analysts" — "AI teaches
everyone to think like an analyst".
